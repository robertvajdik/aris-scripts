function createParagraphPopisProcesu(out,data){ // 10
    out.BeginParagraphF("paragraph_level_0");
    out.OutputLnF(q.getText(80), "HeaderTOC0");
    out.EndParagraph();
    //out.OutputLnF(q.getText(0),"Text1NoSpaceOffset");
    out.BeginParagraphF("paragraph_level_1");
    out.OutputLnF(q.getText(81), "HeaderTOC1");
    out.EndParagraph();
    out.OutGraphic(lineImage, -1,  lineImage.getWidth (Constants.SIZE_LOMETRIC), lineImage.getHeight (Constants.SIZE_LOMETRIC));
    graphicout(outFile, data.masterModel);
    out.OutputLnF("", "Text1");
    
    var mdata = new ModelsData();
    mdata.readModelsData(data.masterModel);
    
    out.BeginTable(100, Constants.C_BLACK, Constants.C_TRANSPARENT, Constants.FMT_LEFT, 0);
    out.TableRow();
    out.TableCellF(data.masterModel.Name(lang), 100, "attrTableHeader");
    out.TableRow();
    out.TableCellF(getAttrib(data.masterModel,9), 100, "attrTableData");
    out.TableRow();
    out.TableCellF(q.getText(110), 20, "attrTableData");// vlastnik
    out.TableCellF("", 80, "attrTableData");
    for(var it = mdata.vlastnik.iterator(); it.hasNext();){
        out.OutputLnF(it.next().Name(lang), "attrTableData");
    }
    out.TableRow();
    out.TableCellF(q.getText(111), 20, "attrTableData");//manager
    out.TableCellF("", 80, "attrTableData");
    for(var it = mdata.manager.iterator(); it.hasNext();){
        out.OutputLnF(it.next().Name(lang), "attrTableData");
    }
    out.TableRow();
    out.TableCellF(q.getText(112), 20, "attrTableData");//cile
    out.TableCellF("", 80, "attrTableData");
    for(var it = mdata.cile.iterator(); it.hasNext();){
        out.OutputLnF(it.next().Name(lang), "attrTableData");
    }
    out.TableRow();
    out.TableCellF(q.getText(113), 20, "attrTableData");// mereno
    out.TableCellF("", 80, "attrTableData");
    for(var it = mdata.mereno.iterator(); it.hasNext();){
        out.OutputLnF(it.next().Name(lang), "attrTableData");
    }
    out.TableRow();
    out.TableCellF(q.getText(114), 20, "attrTableData");//produkt
    out.TableCellF("", 40, "attrTableData");
    for(var it = mdata.produktVstup.iterator(); it.hasNext();){
        out.OutputLnF(it.next().Name(lang), "attrTableData");
    }
    out.TableCellF("", 40, "attrTableData");
    for(var it = mdata.produktVystup.iterator(); it.hasNext();){
        out.OutputLnF(it.next().Name(lang), "attrTableData");
    }
    out.TableRow();
    out.TableCellF(q.getText(115), 20, "attrTableData");//vstupy vystupy
    out.TableCellF("", 40, "attrTableData");
    for(var it = mdata.vstup.iterator(); it.hasNext();){
        out.OutputLnF(it.next().Name(lang), "attrTableData");
    }
    out.TableCellF("", 40, "attrTableData");
    for(var it = mdata.vystup.iterator(); it.hasNext();){
        out.OutputLnF(it.next().Name(lang), "attrTableData");
    }
    out.TableRow();
    out.TableCellF(q.getText(116), 20, "attrTableData");//znalosti
    out.TableCellF("", 80, "attrTableData");
    for(var it = mdata.znalosti.iterator(); it.hasNext();){
        out.OutputLnF(it.next().Name(lang), "attrTableData");
    }
    out.TableRow();
    out.TableCellF(q.getText(117), 20, "attrTableData");//aplikace
    out.TableCellF("", 80, "attrTableData");
    for(var it = mdata.aplikace.iterator(); it.hasNext();){
        out.OutputLnF(it.next().Name(lang), "attrTableData");
    }
    out.TableRow();
    out.TableCellF(q.getText(118), 20, "attrTableData");//rizika
    out.TableCellF("", 80, "attrTableData");
    for(var it = mdata.riziko.iterator(); it.hasNext();){
        out.OutputLnF(it.next().Name(lang), "attrTableData");
    }
    out.EndTable("", 100, "Arial", 10, Constants.C_BLACK, Constants.C_TRANSPARENT, 0, Constants.FMT_LEFT | Constants.FMT_VTOP, 0);
    
    var sps = new Subprocesy();
    sps.getProcesy(mdata.masterFce);
    
    
    out.BeginParagraphF("paragraph_level_1");
    out.OutputLnF(q.getText(82), "HeaderTOC1");// rozdeleni na subprocesy
    out.EndParagraph();
    out.OutGraphic(lineImage, -1,  lineImage.getWidth (Constants.SIZE_LOMETRIC), lineImage.getHeight (Constants.SIZE_LOMETRIC));
    graphicout(outFile, sps.sprc);
    out.OutputLnF("", "Text1");
    
    //out.OutputLnF(sps.subProcesy, "Text1");
    for(var iti = sps.subProcesy.keySet().iterator(); iti.hasNext();){
        var key = iti.next();
        var sData = sps.subProcesy.get(key);
        out.BeginTable(100, Constants.C_BLACK, Constants.C_TRANSPARENT, Constants.FMT_LEFT, 0);
        out.TableRow();
        out.TableCellF(key, 100, "attrTableHeader");
        out.TableRow();
        out.TableCellF(sData.popis, 100, "attrTableData");
        
        out.TableRow();
        out.TableCellF(q.getText(114), 20, "attrTableData");//produkt
        out.TableCellF("", 80, "attrTableData");
        for(var it = sData.produkt.iterator(); it.hasNext();){
            out.OutputLnF(it.next(), "attrTableData");
        }
        out.TableRow();
        out.TableCellF(q.getText(119), 20, "attrTableData");//mezivystup
        out.TableCellF("", 80, "attrTableData");
        for(var it = sData.mezivystup.iterator(); it.hasNext();){
            out.OutputLnF(it.next(), "attrTableData");
        }
        out.TableRow();
        out.TableCellF(q.getText(120), 20, "attrTableData");//organizace
        out.TableCellF("", 80, "attrTableData");
        for(var it = sData.organizace.iterator(); it.hasNext();){
            out.OutputLnF(it.next(), "attrTableData");
        }
        out.EndTable("", 100, "Arial", 10, Constants.C_BLACK, Constants.C_TRANSPARENT, 0, Constants.FMT_LEFT | Constants.FMT_VTOP, 0);
        out.OutputLnF("", "Text1");
    }
    
    
    out.BeginParagraphF("paragraph_level_1");
    out.OutputLnF(q.getText(83), "HeaderTOC1"); // popis subprocesu
    out.EndParagraph();
    out.OutGraphic(lineImage, -1,  lineImage.getWidth (Constants.SIZE_LOMETRIC), lineImage.getHeight (Constants.SIZE_LOMETRIC));
    
    for(var iti = sps.subProcesy.keySet().iterator(); iti.hasNext();){
        var key = iti.next();
        var sData = sps.subProcesy.get(key);
        
        var ds = new DetailySubprocesu(x.masterModel,sData.GUID);
    
    out.BeginParagraphF("paragraph_level_2");
    out.OutputLnF(key, "HeaderTOC2");
    out.EndParagraph();
    if(sData.model == null){
        continue;
    }
    graphicout(outFile, sData.model);
    out.OutputLnF("", "Text1");

    //out.OutGraphic(lineImage, -1,  lineImage.getWidth (Constants.SIZE_LOMETRIC), lineImage.getHeight (Constants.SIZE_LOMETRIC));
    //out.OutputLnF("", "Text1");
    out.BeginTable(100, Constants.C_BLACK, Constants.C_TRANSPARENT, Constants.FMT_LEFT, 0);
    out.TableRow();
    out.TableCellF(q.getText(130), 20, "attrTableData");
    out.TableCellF("", 80, "attrTableData");
    for(var it = ds.vstupy.iterator(); it.hasNext();){ //vstupy
            out.OutputLnF(it.next(), "attrTableData");
        }
    out.TableRow();
    out.TableCellF(q.getText(131), 20, "attrTableData");
    out.TableCellF("", 80, "attrTableData");
    for(var it = ds.vystupy.iterator(); it.hasNext();){//vystupy
            out.OutputLnF(it.next(), "attrTableData");
        }
        
    for(var itii = ds.functions.keySet().iterator();itii.hasNext();){   
        var itiiKey = itii.next();
        var itiiData = ds.functions.get(itiiKey);
        out.TableRow();
        out.TableCellF(itiiKey+" -> "+itiiData.get("nazev"), 100, "attrTableHeader");
        out.TableRow();
        out.TableCellF(itiiData.get("popis"), 100, "attrTableData");
        out.TableRow();
        out.TableCellF("", 20, "attrTableData");
        out.TableCellF(q.getText(140), 40, "attrTableData");
        out.TableCellF(q.getText(141), 40, "attrTableData");        
        out.TableRow();        
        out.TableCellF(q.getText(142), 20, "attrTableData");//dokumenty
        out.TableCellF("", 40, "attrTableData");
        for(var i1 = itiiData.get("dokumentyVstup").iterator(); i1.hasNext();){
            out.OutputLnF(i1.next(), "attrTableData");
        }
        out.TableCellF("", 40, "attrTableData");
        for(var i1 = itiiData.get("dokumentyVystup").iterator(); i1.hasNext();){
            out.OutputLnF(i1.next(), "attrTableData");
        }
        out.TableRow();        
        out.TableCellF(q.getText(143), 20, "attrTableData");//odborne pojmy
        out.TableCellF("", 40, "attrTableData");
        for(var i1 = itiiData.get("odbornyPojemVstup").iterator(); i1.hasNext();){
            out.OutputLnF(i1.next(), "attrTableData");
        }
        out.TableCellF("", 40, "attrTableData");
        for(var i1 = itiiData.get("odbornyPojemVystup").iterator(); i1.hasNext();){
            out.OutputLnF(i1.next(), "attrTableData");
        }
        out.TableRow();        
        out.TableCellF(q.getText(61),20 , "attrTableData");//aplikace
        out.TableCellF("", 80, "attrTableData");
        for(var i1 = itiiData.get("aplikace").iterator(); i1.hasNext();){
            out.OutputLnF(i1.next(), "attrTableData");
        }
        out.TableRow();        
        out.TableCellF(q.getText(62),20 , "attrTableData");//obrazovky
        out.TableCellF("", 80, "attrTableData");
        for(var i1 = itiiData.get("obrazovky").iterator(); i1.hasNext();){
            out.OutputLnF(i1.next(), "attrTableData");
        }
        out.TableRow();        
        out.TableCellF(q.getText(144),20 , "attrTableData");//provadi
        out.TableCellF("", 80, "attrTableData");
        for(var i1 = itiiData.get("provadi").iterator(); i1.hasNext();){
            out.OutputLnF(i1.next(), "attrTableData");
        }
        out.TableRow();        
        out.TableCellF(q.getText(145),20 , "attrTableData");//spolupracuje
        out.TableCellF("", 80, "attrTableData");
        for(var i1 = itiiData.get("spolupracuje").iterator(); i1.hasNext();){
            out.OutputLnF(i1.next(), "attrTableData");
        }
        out.TableRow();        
        out.TableCellF(q.getText(116),20 , "attrTableData");//znalosti
        out.TableCellF("", 80, "attrTableData");
        for(var i1 = itiiData.get("znalosti").iterator(); i1.hasNext();){
            out.OutputLnF(i1.next(), "attrTableData");
        }
        out.TableRow();        
        out.TableCellF(q.getText(118),20 , "attrTableData");//rizika
        out.TableCellF("", 80, "attrTableData");
        for(var i1 = itiiData.get("rizika").iterator(); i1.hasNext();){
            out.OutputLnF(i1.next(), "attrTableData");
        }
    }
        
        
    out.EndTable("", 100, "Arial", 10, Constants.C_BLACK, Constants.C_TRANSPARENT, 0, Constants.FMT_LEFT | Constants.FMT_VTOP, 0);
    }
}
function createParagraphPrilohyKeSmernici(out,data){ // 11
    out.BeginParagraphF("paragraph_level_0");
    out.OutputLnF(q.getText(90), "HeaderTOC0");
    out.EndParagraph();
    out.OutGraphic(lineImage, -1,  lineImage.getWidth (Constants.SIZE_LOMETRIC), lineImage.getHeight (Constants.SIZE_LOMETRIC));
    //out.OutputLnF(q.getText(0),"Text1NoSpaceOffset");
    //Dialogs.MsgBox("data.getDescData() : "+data.getDescData());
    out.BeginTable(100, Constants.C_BLACK, Constants.C_TRANSPARENT, Constants.FMT_LEFT, 0); 
    for(var it = data.getDescData().keySet().iterator();it.hasNext();){
        var temp = it.next();
        if(temp == null)
            continue;
        var key = java.lang.String(temp);
        var value = data.getDescData().get(key);
        if(key.startsWith("Příloha č")){
            out.TableRow(); 
            out.TableCellF(key,20 , "attrTableData");
            out.TableCellF("",80 , "attrTableData"); 
            out.BeginTable(100, Constants.C_BLACK, Constants.C_TRANSPARENT, Constants.FMT_LEFT| Constants.FMT_NOBORDER, 0); 
            
            var attr = value.Attribute(Constants.AT_EXT_1,lang);
            if(attr.getValue() != null && attr.getValue().length() > 0){
                out.TableRow(); 
                out.TableCellF("<priloha>["+attr.getValue()+"]{"+attr.getValue()+"}",80, "attrTableDataNB");
            }
            attr = value.Attribute(Constants.AT_EXT_2,lang);
            if(attr.getValue() != null && attr.getValue().length() > 0){
                out.TableRow(); 
                out.TableCellF("<priloha>["+attr.getValue()+"]{"+attr.getValue()+"}",80, "attrTableDataNB");
            }
            attr = value.Attribute(Constants.AT_EXT_3,lang);
            if(attr.getValue() != null && attr.getValue().length() > 0){
                out.TableRow(); 
                out.TableCellF("<priloha>["+attr.getValue()+"]{"+attr.getValue()+"}",80, "attrTableDataNB");
            }
            attr = value.Attribute(Constants.AT_LINK,lang);
            if(attr.getValue() != null && attr.getValue().length() > 0){
                out.TableRow(); 
                out.TableCellF("<priloha>["+attr.getValue()+"]{"+attr.getValue()+"}",80, "attrTableDataNB");
            }
            out.EndTable("", 100, "Arial", 10, Constants.C_BLACK, Constants.C_TRANSPARENT, 0, Constants.FMT_LEFT | Constants.FMT_VTOP, 0);
            
        }
    }
    out.EndTable("", 100, "Arial", 10, Constants.C_BLACK, Constants.C_TRANSPARENT, 0, Constants.FMT_LEFT | Constants.FMT_VTOP, 0);
}