function createParagraphProduktySluzby(out,data,produktySluzby){ // 7
    out.BeginParagraphF("paragraph_level_0");
    out.OutputLnF(q.getText(50), "HeaderTOC0");
    out.EndParagraph();
    out.OutGraphic(lineImage, -1,  lineImage.getWidth (Constants.SIZE_LOMETRIC), lineImage.getHeight (Constants.SIZE_LOMETRIC));
    out.OutGraphic(lineImage, -1,  lineImage.getWidth (Constants.SIZE_LOMETRIC), lineImage.getHeight (Constants.SIZE_LOMETRIC));
    out.BeginTable(100, Constants.C_BLACK, Constants.C_TRANSPARENT, Constants.FMT_LEFT, 0);
    out.TableRow();
    out.TableCellF(q.getText(16), 50, "attrTableHeader");
    out.TableCellF(q.getText(17), 50, "attrTableHeader");
    for(var it = produktySluzby.selectedObjects.keySet().iterator(); it.hasNext();){
        var key = it.next();
        var def = produktySluzby.selectedObjects.get(key);
        out.TableRow();
        out.TableCellF(def.Name(lang), 50, "attrTableData");
        out.TableCellF(getAttrib(def,9), 50, "attrTableData");
    }
    out.EndTable("", 100, "Arial", 10, Constants.C_BLACK, Constants.C_TRANSPARENT, 0, Constants.FMT_LEFT | Constants.FMT_VTOP, 0);
    
}
function createParagraphITPodpora(out,data,aplikace,obrazovky){ // 8
    out.BeginParagraphF("paragraph_level_0");
    out.OutputLnF(q.getText(60), "HeaderTOC0");
    out.EndParagraph();
    //out.OutGraphic(lineImage, -1,  lineImage.getWidth (Constants.SIZE_LOMETRIC), lineImage.getHeight (Constants.SIZE_LOMETRIC));
    //out.OutputLnF(q.getText(0),"Text1NoSpaceOffset");
    out.BeginParagraphF("paragraph_level_1");
    out.OutputLnF(q.getText(61), "HeaderTOC1");
    out.EndParagraph();
    out.OutGraphic(lineImage, -1,  lineImage.getWidth (Constants.SIZE_LOMETRIC), lineImage.getHeight (Constants.SIZE_LOMETRIC));
    out.BeginTable(100, Constants.C_BLACK, Constants.C_TRANSPARENT, Constants.FMT_LEFT, 0);
    out.TableRow();
    out.TableCellF(q.getText(16), 50, "attrTableHeader");
    out.TableCellF(q.getText(17), 50, "attrTableHeader");
    for(var it = aplikace.selectedObjects.keySet().iterator(); it.hasNext();){
        var key = it.next();
        var def = aplikace.selectedObjects.get(key);
        out.TableRow();
        out.TableCellF(def.Name(lang), 50, "attrTableData");
        out.TableCellF(getAttrib(def,9), 50, "attrTableData");
    }
    out.EndTable("", 100, "Arial", 10, Constants.C_BLACK, Constants.C_TRANSPARENT, 0, Constants.FMT_LEFT | Constants.FMT_VTOP, 0);
    
    
    out.BeginParagraphF("paragraph_level_1");
    out.OutputLnF(q.getText(62), "HeaderTOC1");
    out.EndParagraph();
    out.OutGraphic(lineImage, -1,  lineImage.getWidth (Constants.SIZE_LOMETRIC), lineImage.getHeight (Constants.SIZE_LOMETRIC));
    out.BeginTable(100, Constants.C_BLACK, Constants.C_TRANSPARENT, Constants.FMT_LEFT, 0);
    out.TableRow();
    out.TableCellF(q.getText(16), 50, "attrTableHeader");
    out.TableCellF(q.getText(17), 50, "attrTableHeader");
    for(var it = obrazovky.selectedObjects.keySet().iterator(); it.hasNext();){
        var key = it.next();
        var def = obrazovky.selectedObjects.get(key);
        out.TableRow();
        out.TableCellF(def.Name(lang), 50, "attrTableData");
        out.TableCellF(getAttrib(def,9), 50, "attrTableData");
    }
    out.EndTable("", 100, "Arial", 10, Constants.C_BLACK, Constants.C_TRANSPARENT, 0, Constants.FMT_LEFT | Constants.FMT_VTOP, 0);
}
function createParagraphRizika(out,data,rizika){ // 9
    out.BeginParagraphF("paragraph_level_0");
    out.OutputLnF(q.getText(70), "HeaderTOC0");
    out.EndParagraph();
    out.OutGraphic(lineImage, -1,  lineImage.getWidth (Constants.SIZE_LOMETRIC), lineImage.getHeight (Constants.SIZE_LOMETRIC));
    //out.OutputLnF(q.getText(0),"Text1NoSpaceOffset");
    out.BeginTable(100, Constants.C_BLACK, Constants.C_TRANSPARENT, Constants.FMT_LEFT, 0);
    out.TableRow();
    out.TableCellF(q.getText(71), 33, "attrTableHeader");
    out.TableCellF(q.getText(72), 33, "attrTableHeader");
    out.TableCellF(q.getText(73), 33, "attrTableHeader");
    for(var it = rizika.selectedObjects.keySet().iterator(); it.hasNext();){
        var key = it.next();
        var def = rizika.selectedObjects.get(key);
        out.TableRow();
        out.TableCellF(def.Name(lang), 33, "attrTableData");
        out.TableCellF(getAttrib(def,9), 33, "attrTableData");
        out.TableCellF(getAttrib(def,9), 33, "attrTableData");
    }
    out.EndTable("", 100, "Arial", 10, Constants.C_BLACK, Constants.C_TRANSPARENT, 0, Constants.FMT_LEFT | Constants.FMT_VTOP, 0);
}