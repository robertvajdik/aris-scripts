function createParagraphUcelSmernice(out,x){
    out.BeginParagraphF("paragraph_level_0");
    out.OutputLnF(q.getText(13), "HeaderTOC0");
    out.EndParagraph();
    out.OutGraphic(lineImage, -1,  lineImage.getWidth (Constants.SIZE_LOMETRIC), lineImage.getHeight (Constants.SIZE_LOMETRIC));
    //out.OutputLnF("","nothing");
    
    out.OutputLnF(x.getDescData().get("Účel směrnice"),"Text1NoSpaceOffset");
    
}

function createParagraphPusobnostSmernice(out,x){
    out.BeginParagraphF("paragraph_level_0");
    out.OutputLnF(q.getText(14), "HeaderTOC0");
    //out.OutputLnF("","nothing");
    out.EndParagraph();
    out.OutGraphic(lineImage, -1,  lineImage.getWidth (Constants.SIZE_LOMETRIC), lineImage.getHeight (Constants.SIZE_LOMETRIC));
    
    out.OutputLnF(x.getDescData().get("Působnost směrnice"),"Text1NoSpaceOffset");
    
}
function createParagraphDefinicePojmuaZkratek(out,x,definicePojmu){ // 3
    out.BeginParagraphF("paragraph_level_0");
    out.OutputLnF(q.getText(15), "HeaderTOC0");
    out.EndParagraph();
    out.OutGraphic(lineImage, -1,  lineImage.getWidth (Constants.SIZE_LOMETRIC), lineImage.getHeight (Constants.SIZE_LOMETRIC));
    //out.OutputLnF(q.getText(0),"Text1NoSpaceOffset");
    out.BeginTable(100, Constants.C_BLACK, Constants.C_TRANSPARENT, Constants.FMT_LEFT, 0);
    out.TableRow();
    out.TableCellF(q.getText(16), 50, "attrTableHeader");
    out.TableCellF(q.getText(17), 50, "attrTableHeader");

    for(var it = definicePojmu.keySet().iterator(); it.hasNext();){
        out.TableRow();
        var key = it.next();
        var def = definicePojmu.get(key);
        out.TableCellF(def.Name(lang), 50, "attrTableData");
        out.TableCellF(getAttrib(def,9), 50, "attrTableData");
    }
    out.EndTable("", 100, "Arial", 10, Constants.C_BLACK, Constants.C_TRANSPARENT, 0, Constants.FMT_LEFT | Constants.FMT_VTOP, 0);
    
}
function createParagraphVzoryDokumentu(out,data,vzoryDokumentu){ // 4
    out.BeginParagraphF("paragraph_level_0");
    out.OutputLnF(q.getText(19), "HeaderTOC0");
    out.EndParagraph();
    out.OutGraphic(lineImage, -1,  lineImage.getWidth (Constants.SIZE_LOMETRIC), lineImage.getHeight (Constants.SIZE_LOMETRIC));
    //out.OutputLnF(q.getText(0),"Text1NoSpaceOffset");
    out.BeginTable(100, Constants.C_BLACK, Constants.C_TRANSPARENT, Constants.FMT_LEFT, 0);
    out.TableRow();
    out.TableCellF(q.getText(16), 33, "attrTableHeader");
    out.TableCellF(q.getText(17), 33, "attrTableHeader");
    out.TableCellF(q.getText(18), 33, "attrTableHeader");
    for(var it = vzoryDokumentu.keySet().iterator(); it.hasNext();){
        
        var key = it.next();
        var def = vzoryDokumentu.get(key);
        var linky = new DokumentyData(def,8,"vzor");
        if( linky != null){
            out.TableRow();
            out.TableCellF(def.Name(lang), 33, "attrTableData");
            out.TableCellF(getAttrib(def,9), 33, "attrTableData");
            out.TableCellF("", 33, "attrTableData");
            out.BeginTable(100, Constants.C_BLACK, Constants.C_TRANSPARENT, Constants.FMT_LEFT| Constants.FMT_NOBORDER, 0); 
            for(var xx = linky.linky.iterator(); xx.hasNext();){
                var next = xx.next();
                out.TableRow(); 
                out.TableCellF("<priloha>["+next+"]{"+next+"}",80, "attrTableDataNB");
            }
            out.EndTable("", 100, "Arial", 10, Constants.C_BLACK, Constants.C_TRANSPARENT, 0, Constants.FMT_LEFT | Constants.FMT_VTOP, 0);
       }
    }
    out.EndTable("", 100, "Arial", 10, Constants.C_BLACK, Constants.C_TRANSPARENT, 0, Constants.FMT_LEFT | Constants.FMT_VTOP, 0);
}

function createParagraphOrganizace(out,data,organizacniUtvary,roleVykonavajici){ // 5
    out.BeginParagraphF("paragraph_level_0");
    out.OutputLnF(q.getText(30), "HeaderTOC0");
    out.EndParagraph();
    //out.OutGraphic(lineImage, -1,  lineImage.getWidth (Constants.SIZE_LOMETRIC), lineImage.getHeight (Constants.SIZE_LOMETRIC));
    //out.OutGraphic(lineImage, -1,  lineImage.getWidth (Constants.SIZE_LOMETRIC), lineImage.getHeight (Constants.SIZE_LOMETRIC));
    //out.OutputLnF(q.getText(0),"Text1NoSpaceOffset");
    out.BeginParagraphF("paragraph_level_1");
    out.OutputLnF(q.getText(31), "HeaderTOC1");
    out.EndParagraph();
    out.OutGraphic(lineImage, -1,  lineImage.getWidth (Constants.SIZE_LOMETRIC), lineImage.getHeight (Constants.SIZE_LOMETRIC));
    out.BeginTable(100, Constants.C_BLACK, Constants.C_TRANSPARENT, Constants.FMT_LEFT, 0);
    out.TableRow();
    out.TableCellF(q.getText(16), 50, "attrTableHeader");
    out.TableCellF(q.getText(17), 50, "attrTableHeader");
    for(var it = organizacniUtvary.selectedObjects.keySet().iterator(); it.hasNext();){
        var key = it.next();
        var def = organizacniUtvary.selectedObjects.get(key);
        out.TableRow();
        out.TableCellF(def.Name(lang), 50, "attrTableData");
        out.TableCellF(getAttrib(def,9), 50, "attrTableData");
    }
    out.EndTable("", 100, "Arial", 10, Constants.C_BLACK, Constants.C_TRANSPARENT, 0, Constants.FMT_LEFT | Constants.FMT_VTOP, 0);
    
    out.BeginParagraphF("paragraph_level_1");
    out.OutputLnF(q.getText(32), "HeaderTOC1");
    out.EndParagraph();
    out.OutGraphic(lineImage, -1,  lineImage.getWidth (Constants.SIZE_LOMETRIC), lineImage.getHeight (Constants.SIZE_LOMETRIC));
    out.BeginTable(100, Constants.C_BLACK, Constants.C_TRANSPARENT, Constants.FMT_LEFT, 0);
    out.TableRow();
    out.TableCellF(q.getText(16), 50, "attrTableHeader");
    out.TableCellF(q.getText(17), 50, "attrTableHeader");
    for(var it = roleVykonavajici.selectedObjects.keySet().iterator(); it.hasNext();){
        var key = it.next();
        var def = roleVykonavajici.selectedObjects.get(key);
        out.TableRow();
        out.TableCellF(def.Name(lang), 50, "attrTableData");
        out.TableCellF(getAttrib(def,9), 50, "attrTableData");
    }
    out.EndTable("", 100, "Arial", 10, Constants.C_BLACK, Constants.C_TRANSPARENT, 0, Constants.FMT_LEFT | Constants.FMT_VTOP, 0);
}

function createParagraphZnalosti(out,data,znalosti){ // 6
    out.BeginParagraphF("paragraph_level_0");
    out.OutputLnF(q.getText(40), "HeaderTOC0");
    out.EndParagraph();
    out.OutGraphic(lineImage, -1,  lineImage.getWidth (Constants.SIZE_LOMETRIC), lineImage.getHeight (Constants.SIZE_LOMETRIC));
    out.BeginTable(100, Constants.C_BLACK, Constants.C_TRANSPARENT, Constants.FMT_LEFT, 0);
    out.TableRow();
    out.TableCellF(q.getText(16), 50, "attrTableHeader");
    out.TableCellF(q.getText(17), 50, "attrTableHeader");
    for(var it = znalosti.selectedObjects.keySet().iterator(); it.hasNext();){
        var key = it.next();
        var def = znalosti.selectedObjects.get(key);
        out.TableRow();
        out.TableCellF(def.Name(lang), 50, "attrTableData");
        out.TableCellF(getAttrib(def,9), 50, "attrTableData");
    }
    out.EndTable("", 100, "Arial", 10, Constants.C_BLACK, Constants.C_TRANSPARENT, 0, Constants.FMT_LEFT | Constants.FMT_VTOP, 0);
    
}