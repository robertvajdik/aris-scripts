function Textdata(){
    this.dataCZ = new java.util.HashMap();
    this.dataEN = new java.util.HashMap();
    
    this.getText = function(what){
        try{   
            if(lang == Constants.LCID_CZECH){
                 return this.dataCZ.get(what);
            }
            if(lang == Constants.LCID_ENGLISHSTD || lang == Constants.LCID_ENGLISHUS){
                return this.dataEN.get(what);
            }
            return "n/a";
        }catch(e){
            return "n/a";
        }
    }
    
    this.fillStorageData = function(){
        this.dataCZ.put(0,"dummy text");
        this.dataEN.put(0,"dummy text"); 

        //hlavicka
        this.dataCZ.put(1,"Business Requirements");
        this.dataEN.put(1,"");  
        this.dataCZ.put(10001,"č.");
        this.dataEN.put(10001,"");  
        this.dataCZ.put(2,"ČSOB Pojišťovna, a. s., člen holdingu ČSOB");
        this.dataEN.put(2,""); 
        this.dataCZ.put(3,"Strana ");
        this.dataEN.put(3,"Page "); 
        this.dataCZ.put(4," z ");
        this.dataEN.put(4," from "); 
        
        //paticka
        this.dataCZ.put(5,"Vytvořil:");
        this.dataEN.put(5,"Created by:"); 
        this.dataCZ.put(6,"Vlastník:");
        this.dataEN.put(6,"Owner:"); 
        this.dataCZ.put(7,"Proved by:");
        this.dataEN.put(7,"Proved by:"); 
        this.dataCZ.put(8,"Jméno");
        this.dataEN.put(8,"Name"); 
        this.dataCZ.put(9,"Datum");
        this.dataEN.put(9,"Date"); 
        this.dataCZ.put(10,"Podpis");
        this.dataEN.put(10,"Signature"); 
        this.dataCZ.put(11,"Clase of infomation");
        this.dataEN.put(11,"Clase of infomation"); 

        //TOC
        this.dataCZ.put(12,"Obsah:");
        this.dataEN.put(12,"Content:"); 
        
        //BODY
        this.dataCZ.put(13,"Účel směrnice ");
        this.dataEN.put(13,""); 
        this.dataCZ.put(14,"Působnost směrnice");
        this.dataEN.put(14,""); 
        this.dataCZ.put(15,"Definice pojmů a zkratek použitých ve směrnici procesu ");
        this.dataEN.put(15,""); 
        
        this.dataCZ.put(16,"Název");
        this.dataEN.put(16,""); 
        this.dataCZ.put(17,"Popis");
        this.dataEN.put(17,""); 
        this.dataCZ.put(18,"Soubor");
        this.dataEN.put(18,""); 
        this.dataCZ.put(19,"Vzory dokumentů");
        this.dataEN.put(19,""); 
        
        this.dataCZ.put(30,"Organizace");
        this.dataEN.put(30,""); 
        this.dataCZ.put(31,"Organizační útvary/pracovní skupiny vykonávající proces");
        this.dataEN.put(31,""); 
        this.dataCZ.put(32,"Role vykonávající proces ");
        this.dataEN.put(32,""); 
        
        this.dataCZ.put(40,"Znalosti");
        this.dataEN.put(40,""); 
        
        this.dataCZ.put(50,"Produkty - služby");
        this.dataEN.put(50,""); 
        
        this.dataCZ.put(60,"IT podpora");
        this.dataEN.put(60,""); 
        this.dataCZ.put(61,"Aplikace");
        this.dataEN.put(61,""); 
        this.dataCZ.put(62,"Obrazovky");
        this.dataEN.put(62,""); 
        
        this.dataCZ.put(70,"Rizika");
        this.dataEN.put(70,"");
        this.dataCZ.put(71,"Název");
        this.dataEN.put(71,""); 
        this.dataCZ.put(72,"Kód rizika");
        this.dataEN.put(72,""); 
        this.dataCZ.put(73,"Popis/Definice");
        this.dataEN.put(73,""); 

        this.dataCZ.put(80,"Popis procesu");
        this.dataEN.put(80,""); 
        this.dataCZ.put(81,"Základní charakteristika procesu");
        this.dataEN.put(81,""); 
        this.dataCZ.put(82,"Rozdělení procesu na subprocesy");
        this.dataEN.put(82,""); 
        this.dataCZ.put(83,"Detailní popis procesu");
        this.dataEN.put(83,""); 
        this.dataCZ.put(84,"Posouzení návrhu pohledávky z LPU");
        this.dataEN.put(84,""); 
        
        this.dataCZ.put(110,"Vlastník procesu"); 
        this.dataEN.put(110,""); 
        this.dataCZ.put(111,"Manažer procesu"); 
        this.dataEN.put(111,""); 
        this.dataCZ.put(112,"Cíle"); 
        this.dataEN.put(112,""); 
        this.dataCZ.put(113,"Měřeno"); 
        this.dataEN.put(113,""); 
        this.dataCZ.put(114,"Produkt"); 
        this.dataEN.put(114,""); 
        this.dataCZ.put(115,"Vstupy / Výstupy"); 
        this.dataEN.put(115,""); 
        this.dataCZ.put(116,"Znalosti"); 
        this.dataEN.put(116,""); 
        this.dataCZ.put(117,"Aplikace"); 
        this.dataEN.put(117,""); 
        this.dataCZ.put(118,"Riziko"); 
        this.dataEN.put(118,""); 
        this.dataCZ.put(119,"Mezivýstup"); 
        this.dataEN.put(119,""); 
        this.dataCZ.put(120,"Organizace"); 
        this.dataEN.put(120,""); 
        
        this.dataCZ.put(130,"Vstupní událost/i"); 
        this.dataEN.put(130,""); 
        this.dataCZ.put(131,"Výstupní událost/i"); 
        this.dataEN.put(131,""); 
        
        this.dataCZ.put(140,"Vstupy"); 
        this.dataEN.put(140,""); 
        this.dataCZ.put(141,"Výstupy"); 
        this.dataEN.put(141,"");         
        this.dataCZ.put(142,"Dokumenty"); 
        this.dataEN.put(142,"");         
        this.dataCZ.put(143,"Odborné pojmy"); 
        this.dataEN.put(143,"");         
        this.dataCZ.put(144,"Provádí"); 
        this.dataEN.put(144,"");         
        this.dataCZ.put(145,"Spolupracuje"); 
        this.dataEN.put(145,"");         
        
        this.dataCZ.put(90,"Přílohy ke směrnici");
        this.dataEN.put(90,""); 
        
    }
    this.fillStorageData();
}