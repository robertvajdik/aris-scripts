function handleData(){
    this.descData = new java.util.HashMap();
    this.descData.put("n/a","n/a");
    this.descData.put(null,"n/a");
    this.topModels = new java.util.HashMap();
    this.subModels = new java.util.HashMap();
    this.masterModel = null;
    
    this.getDescData = function(){
        return this.descData;
    }
    this.getTopModels = function(){
        return this.topModels;
    }
    this.getsubModels = function(){
        return this.subModels;
    }
    
    
    this.getTopModelInfo = function(){
    try{
        var selectedModel = ArisData.getSelectedModels()[0];
        if(selectedModel.TypeNum() != Constants.MT_FUNC_ALLOC_DGM){
            throw "modell error : FAD required !";
        }
        var descModel = this.getDescription(selectedModel.ObjOccList ( ));
        this.parseDescModel(descModel);
        this.topModels.putAll(this.scanEntryPoint(selectedModel.ObjOccList ( )));
        //Dialogs.MsgBox(this.descData);
        for(var it = this.topModels.keySet().iterator(); it.hasNext();){
            var key = it.next();
            this.masterModel = this.topModels.get(key);
        }
    }catch(ex){
        Dialogs.MsgBox("getTopModelInfo : "+ex);
        throw ex;
    }
}
    this.getQDescription = function(model){
        var occs = model.ObjOccList();
        for(var index in occs){
            var occ = occs[index];
            var def = occ.ObjDef();
            var key = new java.lang.String(def.Name(lang));
            //data.put(def.Name(lang),occ.getSymbol());
            if(def.TypeNum() == Constants.OT_CASUALOBJ && occ.getSymbol() == 634){
                if(key.startsWith("Příloha č")){
                    this.descData.put(def.Name(lang),def);
                }else{
                    this.descData.put(def.Name(lang),this.getAttrib(def,9));
                }
            }
        }
    }
    this.parseDescModel = function(model){
    var occs = model.ObjOccList();
    for(var index in occs){
        var occ = occs[index];
        var def = occ.ObjDef();
        //data.put(def.Name(lang),occ.getSymbol());
        if(def.TypeNum() == Constants.OT_CASUALOBJ && (occ.getSymbol() == 639 || occ.getSymbol() == 634)){
            var key = new java.lang.String(def.Name(lang));
            var cxns = occ.Cxns();
            for(var iindex in cxns){
                var cxn = cxns[iindex];
                var value = cxn.TargetObjOcc().ObjDef().Name(lang);
                this.descData.put(key,value);
            }
        }
    }
    this.getQDescription(model);
    //Dialogs.MsgBox(data);
    
}
    this.getDescription = function(occList){
    for(var occIndex in occList){
        var objDef = occList[occIndex].ObjDef();
        if(objDef.TypeNum() == Constants.OT_INFO_CARR){
           return objDef.AssignedModels(Constants.MT_CASUALMOD)[0];
        }
    }
    
}
    this.scanEntryPoint = function(occList){
    var ret = new java.util.HashMap();
    for(var occIndex in occList){
        var objDef = occList[occIndex].ObjDef();
        if(objDef.TypeNum() == Constants.OT_FUNC){
           var searchArr = new Array();
           searchArr.push(Constants.MT_FUNC_ALLOC_DGM);
           //searchArr.push(Constants.MT_VAL_ADD_CHN_DGM );
           ret.putAll(this.scanAssModels(objDef.AssignedModels(searchArr)));
           //Dialogs.MsgBox("this.topModels : "+this.topModels);
        }
    }
    return ret;
   
}

    this.scanAssModels = function(models){
        var ret = new java.util.HashMap();
        for(var index in models){
            var model = models[index];
            ret.put(model.Name(lang),model);
        }
        return ret;
    }
    
    this.scanTopModel = function(model){
        try{
            var subModels = new java.util.TreeMap();
            this.subModels = new java.util.TreeMap();
            var functOccList = model.ObjOccListFilter(Constants.OT_FUNC);
            for(var findex in functOccList){
                var fceOcc = functOccList[findex];
                //Dialogs.MsgBox("fceOcc.getSymbol() : "+fceOcc.getSymbol());
                if(fceOcc.getSymbol() == 335 || fceOcc.getSymbol() == 141){ //symbol funkce v EPV & VAC
                    if(fceOcc.ObjDef().AssignedModels().length > 0 && this.getAttribs(fceOcc.ObjDef()).get(8) != null){
                        //subModels.put(this.getAttribs(fceOcc.ObjDef()).get(8)+" "+fceOcc.ObjDef().Name(lang),fceOcc.ObjDef()/*this.scanAssModels(fceOcc.ObjDef().AssignedModels())*/);
                        subModels.put(this.getAttribs(fceOcc.ObjDef()).get(8)+" "+fceOcc.ObjDef().Name(lang),fceOcc.ObjDef()/*this.scanAssModels(fceOcc.ObjDef().AssignedModels())*/);
                    }
                    //if(this.getAttrib(fceOcc.ObjDef(),8) != null && this.getAttrib(fceOcc.ObjDef(),9) > 0){
                        //this.subModels.put(this.getAttribs(fceOcc.ObjDef()).get(8)+" "+fceOcc.ObjDef().Name(lang),fceOcc.ObjDef());
                        //this.subModels.put(this.getAttrib(fceOcc.ObjDef(),8)+" "+fceOcc.ObjDef().Name(lang),fceOcc.ObjDef());
                        this.subModels.put(this.getAttribs(fceOcc.ObjDef()).get(8)+" "+fceOcc.ObjDef().Name(lang),fceOcc.ObjDef());
                    //}
               }
            }
            //Dialogs.MsgBox("this.subModels : "+subModels);
            return subModels;
        }catch(ex){
            Dialogs.MsgBox("scanTopModel : "+ex+"\r\n"+model);
        }
    }
    this.getAttrib = function(object,id){
        var attr = object.Attribute(id,lang);
        return attr.getValue();
    }
    this.getAttribs = function(object){
        var ret = new java.util.HashMap();
        var attrs = object.AttrList(lang);
        for(var aIndex in attrs){
            var attr = attrs[aIndex];
            ret.put(attr.TypeNum(),attr.getValue());
        }
    return ret;    
    }
    
    this.getFunctionOcc = function(occList){
    var ret = new java.util.ArrayList();
    for(var occIndex in occList){
        var objOcc = occList[occIndex];
        if(objOcc.ObjDef().TypeNum() == Constants.OT_FUNC){
            ret.add(objDef());
        }
    }
    return ret;
}
}