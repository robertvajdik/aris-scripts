function DokumentyData(def,id,text){
try{
    this.linky = new java.util.ArrayList();
    
    var attr = def.Attribute(id,lang);
    var xtext = new java.lang.String(attr.getValue());
    if(xtext.indexOf(text) < 0 )
        return null;
    attr = def.Attribute(Constants.AT_EXT_1,lang);
    if(attr.getValue() != null && attr.getValue().length() > 0)
        this.linky.add(attr.getValue());
    
    attr = def.Attribute(Constants.AT_EXT_2,lang);
    if(attr.getValue() != null && attr.getValue().length() > 0)
        this.linky.add(attr.getValue());
    
    attr = def.Attribute(Constants.AT_EXT_3,lang);
    if(attr.getValue() != null && attr.getValue().length() > 0)
        this.linky.add(attr.getValue());
    
    attr = def.Attribute(Constants.AT_LINK,lang);
    if(attr.getValue() != null && attr.getValue().length() > 0)
        this.linky.add(attr.getValue());
}catch(ex){
    Dialogs.MsgBox("DokumentyData : "+ex);
    throw ex;
}
}
function DataModelTree(){
    
    this.scannedModels = new java.util.ArrayList();
    this.scannedObjects = new java.util.ArrayList();
    this.selectedObjects = new java.util.TreeMap(czechSort);
    this.models = new java.util.HashMap();
    this.currentModel = null;
    this.xmModelsGUIDs = new java.util.ArrayList();
    
    this.scanSelectedmodelsForObjects = function(){
        try{
            for(var it = this.models.keySet().iterator(); it.hasNext();){
                var key = it.next();
                var model = this.models.get(key);
                var occs = model.ObjOccList();
                for(var index in occs){
                    var occ = occs[index];
                    var def = occ.ObjDef();
                    if(this.scannedObjects.contains(new java.lang.Integer(def.TypeNum()))){
                        this.selectedObjects.put(def.Name(lang),def);
                    }
                }
            }
            
        }catch(ex){
            Dialogs.MsgBox("DataModelTree.scanSelectedmodelsForObjects : "+ex);
            throw ex;
        }
    }
    
    this.scanModelTree = function(model){
        try{
            //this.currentModel = model.Name(lang);
            if(this.xmModelsGUIDs.contains(new java.lang.String(model.GUID())))
                return;
            else
                this.xmModelsGUIDs.add(new java.lang.String(model.GUID()));
            if(this.scannedModels.contains(new java.lang.Integer(model.TypeNum()))){
                this.models.put(model.GUID(),model);
            }
            
            var occs = model.ObjOccList();
            for(var index in occs){
                var occ = occs[index];
                var def = occ.ObjDef();
                var assign = def.AssignedModels();
                for(var assIndex in assign){
                    var assModel = assign[assIndex];
                    this.scanModelTree(assModel);
                }
            }
        }catch(ex){
            Dialogs.MsgBox("DataModelTree.scanModelTree : "+ex);
            throw ex;
        }
        this.scanSelectedmodelsForObjects();
    }
    this.getAttrib = function(object,id){
        var attr = object.Attribute(id,lang);
        return attr.getValue();
    }
    
    this.addModelToList = function(modelNumber){
        this.scannedModels.add(new java.lang.Integer(modelNumber));
    }
    this.addObjectToList = function(objNumber){
        this.scannedObjects.add(new java.lang.Integer(objNumber));
    }
    
}