function SubprocesData(nazev, popis, guid, model){
    this.nazev = nazev;
    this.popis = popis;
    this.GUID = guid;
    this.model = model;
    this.produkt = new java.util.TreeSet(czechSort);
    this.mezivystup = new java.util.TreeSet(czechSort);
    this.organizace = new java.util.TreeSet(czechSort);
    
}
function Subprocesy(){
    this.sprc = null;
    this.subProcesy = new java.util.TreeMap(czechSort);
    
    this.getProcesy = function(fce){
        try{
            //Dialogs.MsgBox("fce : "+fce.Name(lang));
            this.sprc = fce.AssignedModels(Constants.MT_VAL_ADD_CHN_DGM)[0];
            var occs = this.sprc.ObjOccList();
            for(var index in occs){
                var occ = occs[index];
                var def = occ.ObjDef();
                if(def.TypeNum() == Constants.OT_FUNC){
                    var key = def.Name(lang);
                    var model = def.AssignedModels ( Constants.MT_EEPC )[0];
                    var value = this.scanConnections(new SubprocesData(key, getAttrib(def,9), def.GUID(),model),def);
                    this.subProcesy.put(key,value);
                }
            }
            this.subProcesy.remove(fce.Name(lang));
        }catch(ex){
            Dialogs.MsgBox("Subprocesy.getProcesy : "+ex);
            throw ex;
        }
    }
    this.scanConnections = function(SubprocesData,fce){
        try{
            var switchType = 0;
            var xObj = null;
            var cxns = fce.CxnList();
            for(var index in cxns){
                var cxn = cxns[index];
                var source = cxn.SourceObjDef();
                var target = cxn.TargetObjDef();
                
                if(fce.GUID() == source.GUID()){
                    //Dialogs.MsgBox("fce je source dest :"+target.Name(lang));
                    switchType = target.TypeNum();
                    xObj = target;
                }else{
                    //Dialogs.MsgBox("target je source dest :"+source.Name(lang));                    
                    switchType = source.TypeNum();
                    xObj = source;
                }
                switch(switchType){
                    case 153 : //produkt - nezivystup
                        var occs = xObj.OccListInModel(this.sprc);
                        for(var xx in occs){
                            var occ = occs[xx];
                            if(occ.SymbolNum() == 465){//produkt
                                SubprocesData.produkt.add(xObj.Name(lang)); 
                            }
    
                            if(occ.SymbolNum() == 530){//mezivystup
                                SubprocesData.mezivystup.add(xObj.Name(lang)); 
                            }
                        }
                        break;                        
                    case 43 : //organizace
                        SubprocesData.organizace.add(xObj.Name(lang)); 
                        break;
                }
            }
        return SubprocesData;
        }catch(ex){
            Dialogs.MsgBox("Subprocesy.scanConnections : "+ex);
            throw ex;
        }   
    }
}