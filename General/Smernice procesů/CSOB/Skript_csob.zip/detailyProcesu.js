function DetailySubprocesu(masterModel,GUID){
    this.vstupy = new java.util.TreeSet(czechSort);
    this.vystupy = new java.util.TreeSet(czechSort);
    this.functions = new java.util.TreeMap(czechSort);
    this.subEPC = null;
    
    this.getInfo = function(){
        try{
            var masterItem = masterModel.Database().FindGUID(GUID);
            //Dialogs.MsgBox("masterItem : "+masterItem.Name(lang));
            this.subEPC = masterItem.AssignedModels(Constants.MT_EEPC)[0];
            //Dialogs.MsgBox("this.subEPC : "+this.subEPC);
            if(this.subEPC != null){
                this.getVstupy();
                this.getFunctions();
            }
            
        }catch(ex){
            Dialogs.MsgBox("DetailySubprocesu.getInfo : "+ex);
            throw ex;
        }
    }
    
    this.getFunctionInfo = function(occ){
        try{
            var ret = new java.util.HashMap();
            var dokumentyVstup = new java.util.TreeSet(czechSort);
            var dokumentyVystup = new java.util.TreeSet(czechSort);
            var odbornyPojemVstup = new java.util.TreeSet(czechSort);
            var odbornyPojemVystup = new java.util.TreeSet(czechSort);
            var aplikace = new java.util.TreeSet(czechSort);
            var obrazovky = new java.util.TreeSet(czechSort);
            var provadi = new java.util.TreeSet(czechSort);
            var spolupracuje = new java.util.TreeSet(czechSort);
            var znalosti = new java.util.TreeSet(czechSort);
            var rizika = new java.util.TreeSet(czechSort);
            
            fce = occ.ObjDef();
            var switchType = 0;
            var xObj = null;
            var cxns = fce.CxnList();
            for(var index in cxns){
                var cxn = cxns[index];
                var source = cxn.SourceObjDef();
                var target = cxn.TargetObjDef();
                
                if(fce.GUID() == source.GUID()){
                    //Dialogs.MsgBox("fce je source dest :"+target.Name(lang));
                    switchType = target.TypeNum();
                    xObj = target;
                }else{
                    //Dialogs.MsgBox("target je source dest :"+source.Name(lang));                    
                    switchType = source.TypeNum();
                    xObj = source;
                }
                switch(switchType){
                    case 27 : //dokumenty
                        if(cxn.TypeNum() == 53) // poskytuje vstup pro
                            dokumentyVstup.add(xObj.Name(lang));
                        if(cxn.TypeNum() == 28) // vytvari vystup pro 
                            dokumentyVystup.add(xObj.Name(lang));
                        break;
                    case 58 : //odborne pojmy
                        if(cxn.TypeNum() == 49) // je vstupem pro
                            odbornyPojemVstup.add(xObj.Name(lang));
                        if(cxn.TypeNum() == 50) // ma vystup
                            odbornyPojemVystup.add(xObj.Name(lang));
                        break;
                    case 6 : //aplikace
                    case 37:
                    case 105:
                            aplikace.add(xObj.Name(lang));
                        break;
                    case 31 : //obrazovky
                            obrazovky.add(xObj.Name(lang));
                        break;
                    case 46 : //provadi
                    case 78 :
                    case 128 :
                        if(cxn.TypeNum() == 218) // provadi
                            provadi.add(xObj.Name(lang));
                        if(cxn.TypeNum() == 296) // spolupracuje
                            spolupracuje.add(xObj.Name(lang));
                        break;
                     case 231 : //znalosti
                     case 230 :
                            znalosti.add(xObj.Name(lang));
                        break;
                     
                     case 159 : //riziko
                            rizika.add(xObj.Name(lang));
                        break;
                }
            }
            
            ret.put("nazev",fce.Name(lang));
            ret.put("popis",getAttrib(fce,9));
            ret.put("dokumentyVstup",dokumentyVstup);
            ret.put("dokumentyVystup",dokumentyVystup);
            ret.put("odbornyPojemVstup",odbornyPojemVstup);
            ret.put("odbornyPojemVystup",odbornyPojemVystup);
            ret.put("aplikace",aplikace);
            ret.put("obrazovky",obrazovky);
            ret.put("provadi",provadi);
            ret.put("spolupracuje",spolupracuje);
            ret.put("znalosti",znalosti);
            ret.put("rizika",rizika);
            return ret;
        }catch(ex){
            Dialogs.MsgBox("DetailySubprocesu.getFunctionInfo : "+ex);
            throw ex;
        }
            
    }
    
    this.getFunctions = function(){
        try{
            var occs = this.subEPC.ObjOccListFilter (Constants.OT_FUNC)
            for(var index in occs){
                var occ = occs[index];
                if(occ.SymbolNum ( ) == 335){
                    var infos = this.getFunctionInfo(occ);
                    this.functions.put(getAttrib(occ.ObjDef(),Constants.AT_ID),infos);
                }
            }
        }catch(ex){
            Dialogs.MsgBox("DetailySubprocesu.getFunctions : "+ex);
            throw ex;
        }
            
    }
    
    this.getVstupy = function(){
        try{
            var occs = this.subEPC.ObjOccListFilter (Constants.OT_EVT)
            for(var index in occs){
                var def = occs[index].ObjDef();
                var incxn = def.CxnList ( Constants.EDGES_IN );
                if(incxn.length < 1)
                    this.vstupy.add(def.Name(lang));
                var outcxn = def.CxnList ( Constants.EDGES_OUT );
                if(outcxn.length < 1)
                    this.vystupy.add(def.Name(lang));
                
                var cxns = def.CxnList();
                for(var index in cxns){
                    var cxn = cxns[index];
                    var source = cxn.SourceObjDef();
                    var target = cxn.TargetObjDef();
                
                    if(source.TypeNum() == Constants.OT_FUNC && this.getSymbol(this.subEPC,source) == 94){
                        this.vstupy.add(def.Name(lang));
                    }
                    if(target.TypeNum() == Constants.OT_FUNC && this.getSymbol(this.subEPC,target) == 94){
                        this.vystupy.add(def.Name(lang));
                    }
                    
                    if(source.TypeNum() == Constants.OT_RULE && this.nasledujeRozhrani(this.subEPC,source,Constants.EDGES_IN)){
                        this.vstupy.add(def.Name(lang));
                    }
                    if(target.TypeNum() == Constants.OT_RULE && this.nasledujeRozhrani(this.subEPC,target,Constants.EDGES_OUT)){
                        this.vystupy.add(def.Name(lang));
                    }
                    var a = 10;
                }
            }
        }catch(ex){
            Dialogs.MsgBox("DetailySubprocesu.getvstupy : "+ex+"\r\n"+this.subEPC);
            throw ex;
        }
    }
    this.nasledujeRozhrani = function(model,def,mode){
        try{
            var cxnDs = def.CxnList ( mode );
            //Dialogs.MsgBox("nasledujeRozhrani : "+def.Name(lang)+" "+cxnDs.length+" model "+this.subEPC.Name(lang));
            for(var index in cxnDs){
                var cxnD = cxnDs[index];
                var xsource = cxnD.SourceObjDef ( );
                var xtarget = cxnD.TargetObjDef ( );
                var xobj = null;
                
                if(xsource.GUID() == def.GUID()){ // stejne source
                    xobj = xtarget;
                }
                if(xtarget.GUID() == def.GUID()){ // stejny target
                    xobj = xsource;
                }
                
                var symbol = this.getSymbol(model,xobj);
                //Dialogs.MsgBox(index+" type : "+xobj.TypeNum()+" symbol "+symbol+" guid : "+xobj.GUID());
                if(xobj.TypeNum() == Constants.OT_FUNC && symbol == 94)
                    return true;
            }
            return false;
        }catch(ex){
            Dialogs.MsgBox("DetailySubprocesu.nasledujeRozhrani : "+ex);
            throw ex;
        }
    }
    this.getSymbol = function(model,def){
        try{
            var occ = def.OccListInModel (model)[0];
            return occ.SymbolNum ( );
        }catch(ex){
            //Dialogs.MsgBox("DetailySubprocesu.getSymbol : "+ex+"\r\n"+this.subEPC);
            //throw ex;
        }
    }
    this.getInfo();
}