function header(out,x){
    
    out.BeginHeader();
    out.BeginTable(100, Constants.C_BLACK, Constants.C_TRANSPARENT, Constants.FMT_LEFT, 0);
    out.TableRow();
    out.TableCellF("", 20, "thlavicka3");  
    var picData = Context.createPicture("CSOB_Pojistovna_side_r.gif");
    out.OutGraphic(picData, 10,  picData.getWidth (Constants.SIZE_LOMETRIC), picData.getHeight (Constants.SIZE_LOMETRIC));
    out.TableCellF(x.getDescData().get("<<_nazev_dokumentu_>>"), 50, "thlavicka4");
    out.TableCellF(q.getText(2), 30, "thlavicka3");
    out.TableRow();
    out.TableCellF("", 80, "thlavicka3");
    out.TableCellF("",20, "thlavicka3");    
    out.Output(q.getText(3),"Arial", 9, Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_RIGHT,0);
    out.OutputField(Constants.FIELD_PAGE , "Arial", 9, Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_RIGHT);
    out.Output(q.getText(4),"Arial", 9, Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_RIGHT,0);
    out.OutputField(Constants.FIELD_NUMPAGES, "Arial", 9, Constants.C_BLACK, Constants.C_TRANSPARENT, Constants.FMT_RIGHT);
    
    out.EndTable("", 100, "Arial", 1, Constants.C_BLACK, Constants.C_TRANSPARENT, 0, Constants.FMT_LEFT | Constants.FMT_VTOP, 0);
    
    out.EndHeader();
}
function footer(out,x){
    out.BeginFooter();
    out.BeginTable(100, Constants.C_BLACK, Constants.C_TRANSPARENT, Constants.FMT_LEFT, 0);
    out.TableRow();
    out.TableCellF("",25, "bhlavicka1");    
    out.TableCellF(q.getText(5),25, "bhlavicka1");    
    out.TableCellF(q.getText(6),25, "bhlavicka1");        
    out.TableCellF(q.getText(7),25, "bhlavicka1");   
    out.TableRow();
    out.TableCellF("",25, "bhlavicka1"); 
    out.BeginTable(100, Constants.C_BLACK, Constants.C_TRANSPARENT, Constants.FMT_LEFT, 0);
        out.TableRow();
        out.TableCellF(q.getText(8),100, "bhlavicka3"); 
        out.TableRow();
        out.TableCellF(q.getText(9),100, "bhlavicka2"); 
        out.TableRow();
        out.TableCellF(q.getText(10),100, "bhlavicka2"); 
    out.EndTable("", 100, "Arial", 10, Constants.C_BLACK, Constants.C_TRANSPARENT, 0, Constants.FMT_LEFT | Constants.FMT_VTOP, 0);
    out.TableCellF("",25, "bhlavicka4"); 
    out.TableCellF("",25, "bhlavicka4"); 
    out.TableCellF("",25, "bhlavicka4"); 
    out.TableRow();
    out.TableCellF(q.getText(11),50, "bhlavicka1"); 
    out.TableCellF("",50, "bhlavicka1");     
    out.EndTable("", 100, "Arial", 10, Constants.C_BLACK, Constants.C_TRANSPARENT, 0, Constants.FMT_LEFT | Constants.FMT_VTOP, 0);
    out.EndFooter();
}
function newfooter(out){
    out.BeginFooter();
    out.EndFooter();
}
function defineformatstyles(out)
{ 
  out.DefineF("Center", "Arial", 11, RGB(0,0,0), Constants.C_TRANSPARENT,  Constants.FMT_CENTER| Constants.FMT_VTOP, 0, 0, 0, 0, 0, 1)
  out.DefineF("Left", "Arial", 11, RGB(0,0,0), Constants.C_TRANSPARENT,  Constants.FMT_LEFT| Constants.FMT_VTOP, 0, 0, 0, 0, 0, 1)
  out.DefineF("thlavicka1", "Arial", 9,  Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_BOLD | Constants.FMT_LEFT | Constants.FMT_NOBORDER, 0, 0, 0, 0, 0, 0);
  out.DefineF("thlavicka2", "Arial", 9,  Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_LEFT | Constants.FMT_NOBORDER, 40, 0, 0, 0, 0, 0);
  out.DefineF("thlavicka3", "Arial", 9,  Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_BOLD | Constants.FMT_CENTER, 0, 0, 0, 0, 0, 0);
  out.DefineF("thlavicka4", "Arial", 12,  Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_BOLD | Constants.FMT_CENTER, 0, 0, 0, 0, 0, 0);
  out.DefineF("bhlavicka1", "Arial", 9,  Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_BOLD | Constants.FMT_LEFT , 0, 0, 0, 0, 0, 0);
  out.DefineF("bhlavicka2", "Arial", 9,  Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_BOLD | Constants.FMT_LEFT | Constants.FMT_NOBORDER, 0, 0, 2, 2, 0, 0);
  out.DefineF("bhlavicka3", "Arial", 9,  Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_BOLD | Constants.FMT_LEFT | Constants.FMT_NOBORDER, 0, 0, 0, 2, 0, 0);
  out.DefineF("bhlavicka4", "Arial", 9,  Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_BOLD | Constants.FMT_LEFT , 0, 0, 0, 2, 0, 0);
  
  out.DefineF("fpage1", "Arial", 38, RGB(0,0,0) , Constants.C_WHITE, Constants.FMT_BOLD | Constants.FMT_CENTER, 0, 0, 10, 10, 0, 0);  
  out.DefineF("fpage11", "Arial", 20, RGB(0,0,0) , Constants.C_WHITE, Constants.FMT_BOLD | Constants.FMT_CENTER, 0, 0, 0, 10, 0, 0);  
  out.DefineF("fpage12", "Arial", 36, RGB(0,0,0) , Constants.C_WHITE, Constants.FMT_CENTER, 0, 0, 0, 0, 0, 0);  
  out.DefineF("fpage2", "Arial", 28, Constants.C_BLACK , Constants.C_WHITE, Constants.FMT_BOLD | Constants.FMT_CENTER, 0, 0, 7, 0, 0, 0);  
    
  out.DefineF("paragraph_level_0", "Arial", 1, RGB(0,0,0), Constants.C_TRANSPARENT,  Constants.FMT_BOLD | Constants.FMT_LEFT| Constants.FMT_VBOTTOM|Constants.FMT_TOCENTRY0 , 0, 0, 2, 2, 0, 0) 
  out.DefineF("paragraph_level_1", "Arial", 1, RGB(0,0,0), Constants.C_TRANSPARENT,  Constants.FMT_BOLD | Constants.FMT_LEFT| Constants.FMT_VBOTTOM| Constants.FMT_TOCENTRY1 , 0, 0, 2, 2, 0, 0) 
  out.DefineF("paragraph_level_2", "Arial", 1, RGB(0,0,0), Constants.C_TRANSPARENT,  Constants.FMT_BOLD | Constants.FMT_LEFT| Constants.FMT_VBOTTOM| Constants.FMT_TOCENTRY2 , 0, 0, 2, 2, 0, 0) 
  out.DefineF("paragraph_level_3", "Arial", 11, RGB(0,0,0), Constants.C_TRANSPARENT,  Constants.FMT_BOLD | Constants.FMT_LEFT| Constants.FMT_VBOTTOM| Constants.FMT_TOCENTRY3 , 0, 0, 0, 0, 0, 0) 
  
  out.DefineF("HeaderTOC0", "Arial", 14, Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_BOLD | Constants.FMT_LEFT | Constants.FMT_VBOTTOM | Constants.FMT_TOCENTRY0 , 0, 0, 0, 0, 0, 0);// | Constants.FMT_UNDERLINE
  out.DefineF("HeaderTOC1", "Arial", 12, Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_BOLD | Constants.FMT_LEFT | Constants.FMT_VBOTTOM | Constants.FMT_TOCENTRY1, 0, 0, 0, 0, 0, 0);
  out.DefineF("HeaderTOC2", "Arial", 11, Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_LEFT | Constants.FMT_VTOP| Constants.FMT_TOCENTRY2, 0, 0, 3, 3, 0, 1);
  out.DefineF("Text1", "Arial", 10, Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_LEFT, 0, 0, 2, 2, 0, 1);
  out.DefineF("Text1NoSpace", "Arial", 10, Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_LEFT, 0, 0, 0, 0, 0, 1);
  out.DefineF("Text1NoSpaceOffset", "Arial", 10, Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_LEFT, 0, 0, 2.5, 0, 0, 1);
  out.DefineF("Text1NoSpaceOffset1", "Arial", 10, Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_LEFT, 0, 0, 0, 0, 0, 1);
  out.DefineF("Text1Bold", "Arial", 10, Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_BOLD | Constants.FMT_LEFT, 0, 0, 2, 2, 0, 1);
  out.DefineF("Text1BoldNoSpace", "Arial", 10, Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_BOLD | Constants.FMT_LEFT, 0, 0, 2.5, 0, 0, 1);
  out.DefineF("nothing", "Arial", 1, Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_BOLD | Constants.FMT_LEFT, 0, 0, 0, 0, 0, 0);
  out.DefineF("linky", "Arial", 5, Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_LEFT, 0, 0, 0, 0, 0, 0);
  
  out.DefineF("attrTableHeader", "Arial", 9, Constants.C_BLACK, RGB(179, 194, 200), Constants.FMT_BOLD | Constants.FMT_LEFT, 2.8, 0, 0, 0, 0, 1);
  out.DefineF("attrTableData", "Arial", 9, Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_LEFT, 2.8, 0, 0, 0, 0, 1);
  out.DefineF("attrTableDataNB", "Arial", 9, Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_LEFT | Constants.FMT_NOBORDER, 2.8, 0, 0, 0, 0, 1);
  out.DefineF("attrTableDistanc", "Arial", 9, Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_LEFT, 0, 0, 2, 2, 0, 1);
  
  out.DefineF("Textlist", "Arial", 10, Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_LEFT, 6, 0, 0, 0, 0, 1);
  
}
function RGB(r, g, b) {
	return (new java.awt.Color(r/255.0,g/255.0,b/255.0,1)).getRGB() & 0xFFFFFF
}
function createTOC(out) {
    out.BeginSection(true, Constants.SECTION_INDEX)
    //setupOutputObject( p_output ) //use defaults
    
    out.SetTOCFormat(0, "Arial", 11, Constants.C_BLACK, Constants.C_WHITE,  Constants.FMT_BOLD |Constants.FMT_LEFT, 0, 0, 2, 0); 
    out.SetTOCFormat(1, "Arial", 10, Constants.C_BLACK, Constants.C_WHITE,  Constants.FMT_BOLD |Constants.FMT_LEFT , 5, 0, 2, 0);
    out.SetTOCFormat(2, "Arial", 10, Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_LEFT, 10, 0, 2, 0);
    out.SetTOCFormat(3, "Arial", 10, Constants.C_BLACK, Constants.C_WHITE, Constants.FMT_LEFT, 0, 0, 2, 0);
    //if(out.GetAutoTOCNumbering ( ) != true)
        out.SetAutoTOCNumbering(true);
    out.BeginParagraphF("Center");
    out.OutputLn(q.getText(12), "arial", 12, RGB(0,0,0), Constants.C_TRANSPARENT,  Constants.FMT_BOLD  |  Constants.FMT_CENTER, 0)
    out.EndParagraph()
    
	out.BeginParagraphF("Left")
    //to format the TOC output use output.SetTOCFormat(iLevel, sFont, iFontSize, nFontColor, nBackgroundColor, nFormat, nLeftIndentation, nRightIndentation, nDistTop, nDistBottom)
	out.OutputField( Constants.FIELD_TOC, "arial", 11, Constants.C_BLACK, Constants.C_TRANSPARENT,  Constants.FMT_LEFT)
	out.EndParagraph()
    
	out.EndSection()  
    
}
function mygraphicout(g_ooutfile, ocurrentmodel) {
    var bmodelcolor = new __holder(false);
    var nscaleoption = new __holder(0);
    var bcutofthegraphic = new __holder(false);
    var ntop = new __holder(0);
    var nbottom = new __holder(0);
    var nleft = new __holder(0);
    var nright = new __holder(0);
    var nwidth = new __holder(0);
    var nheight = new __holder(0);
    var nscalevalue = new __holder(0);
    var nmodelzoom = 0;
    var aPicSize = new Array();
    inputfromregistry(bmodelcolor, nscaleoption, bcutofthegraphic, ntop, nbottom, nleft, nright, nwidth, nheight, nscalevalue, g_ooutfile, true);
    inputfromregistry(bmodelcolor, nscaleoption, bcutofthegraphic, ntop, nbottom, nleft, nright, nwidth, nheight, nscalevalue, g_ooutfile, false);
    switch (nscaleoption.value) {
      case 0:
        nmodelzoom = parseInt(nscalevalue.value);
        break;
      case 1:
        nmodelzoom = 100;
        break;
      case 2:
        nmodelzoom = -1;
        aPicSize = fitPageScale(g_ooutfile.value, ocurrentmodel.Graphic(bcutofthegraphic.value, bmodelcolor.value, Context.getSelectedLanguage()));
        break;
      case 3:
        nmodelzoom = parseInt(ocurrentmodel.getPrintScale());
        break;
    }
    if ((nmodelzoom == -1) && (Context.getSelectedFormat() == Constants.OUTHTML)) {
        g_ooutfile.value.OutGraphic(ocurrentmodel.Graphic(bcutofthegraphic.value, bmodelcolor.value, Context.getSelectedLanguage()), nmodelzoom, aPicSize["WIDTH"] * 10, aPicSize["HEIGHT"] * 10);
    } else {
        //g_ooutfile.value.OutGraphic(ocurrentmodel.Graphic(bcutofthegraphic.value, bmodelcolor.value, Context.getSelectedLanguage()), nmodelzoom, ((nwidth.value - nleft.value) - nright.value), (((nheight.value - ntop.value) - nbottom.value) - 60));
        var pwidth = ((nwidth.value - nleft.value) - nright.value);
        var pheight = (((nheight.value - ntop.value) - nbottom.value) );
        //Dialogs.MsgBox("pwidth : "+ pwidth+" pheight : "+ pheight );
        g_ooutfile.value.OutGraphic(ocurrentmodel.Graphic(bcutofthegraphic.value, bmodelcolor.value, Context.getSelectedLanguage()), nmodelzoom, pwidth, pheight);
    }
}
function getScales(g_ooutfile){
    /*
    return "page width : "+ g_ooutfile.value.GetPageWidth()+
           "page height : " +g_ooutfile.value.GetPageHeight()+
            "left margin : " +g_ooutfile.value.GetLeftMargin());
        nright.value = parseInt(g_ooutfile.value.GetRightMargin());
        ntop.value = parseInt(g_ooutfile.value.GetTopMargin());
        nbottom.value = parseInt(g_ooutfile.value.GetBottomMargin());
        */
}
function myinputfromregistry(bmodelcolor, nscaleoption, bcutofthegraphic, ntop, nbottom, nleft, nright, nwidth, nheight, nscalevalue, g_ooutfile, bcheck) {
    if (bcheck) {
        var sdummy = "";
        sdummy = new String(Context.getProfileString("SCRIPT_atsall", "ModelColor", "-1"));
        if (sdummy == "-1") {
            bmodelcolor.value = false;
        } else {
            bmodelcolor.value = true;
        }
        nscaleoption.value = parseInt(parseInt(Context.getProfileString("SCRIPT_atsall", "ScaleOption", "0")));
        nscalevalue.value = parseInt(parseInt(Context.getProfileString("SCRIPT_atsall", "ScaleValue", "100")));
        sdummy = new String(Context.getProfileString("SCRIPT_atsall", "CutOfTheGraphic", "-1"));
        if (sdummy == "-1") {
            bcutofthegraphic.value = false;
        } else {
            bcutofthegraphic.value = true;
        }
    } else {
        nwidth.value = parseInt(g_ooutfile.value.GetPageWidth());
        nheight.value = parseInt(g_ooutfile.value.GetPageHeight());
        nleft.value = parseInt(g_ooutfile.value.GetLeftMargin());
        nright.value = parseInt(g_ooutfile.value.GetRightMargin());
        ntop.value = parseInt(g_ooutfile.value.GetTopMargin());
        nbottom.value = parseInt(g_ooutfile.value.GetBottomMargin());
    }
}

