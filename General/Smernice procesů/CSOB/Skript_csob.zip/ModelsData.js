function ModelsData(){
    this.masterFce = null;
    this.vlastnik = new java.util.TreeSet(czechSort);
    this.manager = new java.util.TreeSet(czechSort);
    this.cile = new java.util.TreeSet(czechSort);
    this.mereno  = new java.util.TreeSet(czechSort);
    this.produktVstup = new java.util.TreeSet(czechSort);
    this.produktVystup = new java.util.TreeSet(czechSort);
    this.vstup = new java.util.TreeSet(czechSort);
    this.vystup = new java.util.TreeSet(czechSort);
    this.znalosti = new java.util.TreeSet(czechSort);
    this.aplikace = new java.util.TreeSet(czechSort);
    this.riziko = new java.util.TreeSet(czechSort);
    
    this.readModelsData = function(model){
        try{
            this.masterFce = this.getFunction(model);
            if(this.masterFce == null)
                throw "missing main function";
            this.scanConnections(this.masterFce);
            
        }catch(ex){
            Dialogs.MsgBox("ModelsData.readModelsData : "+ex);
            throw ex;
        }
    }
    
    this.scanConnections = function(fce){
        try{
            var switchType = 0;
            var xObj = null;
            var cxns = fce.CxnList();
            for(var index in cxns){
                var cxn = cxns[index];
                var source = cxn.SourceObjDef();
                var target = cxn.TargetObjDef();
                
                if(fce.GUID() == source.GUID()){
                    //Dialogs.MsgBox("fce je source dest :"+target.Name(lang));
                    switchType = target.TypeNum();
                    xObj = target;
                }else{
                    //Dialogs.MsgBox("target je source dest :"+source.Name(lang));                    
                    switchType = source.TypeNum();
                    xObj = source;
                }
                switch(switchType){
                    case 78 : //role
                        if(cxn.TypeNum() == 358) // je procesni manager
                            this.manager.add(this.getFukcniMisto(xObj));
                        if(cxn.TypeNum() == 220) // je odborne odpovedny za   
                            this.vlastnik.add(this.getFukcniMisto(xObj));
                        break;
                    case 86 : //cile
                        this.cile.add(xObj);
                        break;
                    case 244 : //mereno
                        this.mereno.add(xObj);
                        break;
                     case 153 : //produkt
                        if(cxn.TypeNum() == 49) // je vstupem pro
                            this.produktVstup.add(xObj);
                        if(cxn.TypeNum() == 50) // ma vystup
                            this.produktVystup.add(xObj);
                        break;
                     case 27 : //vstup/vystup
                        if(cxn.TypeNum() == 53) // poskytuje vstup pro
                            this.vstup.add(xObj);
                        if(cxn.TypeNum() == 28) // vytvari vystup pro
                            this.vystup.add(xObj);
                        break;
                     case 231 : //znalosti
                     case 230 :
                        this.znalosti.add(xObj);
                        break;
                     case 6 : //aplikace
                     case 37:
                        this.aplikace.add(xObj);
                        break;
                     case 159 : //riziko
                        this.riziko.add(xObj);
                        break;
                }
            }
        }catch(ex){
            Dialogs.MsgBox("ModelsData.scanConnections : "+ex);
            throw ex;
        }    
    }
    this.getFukcniMisto = function(obj){
        try{
            var cxns = obj.CxnListFilter ( Constants.EDGES_INOUT, 480 );//role
            for(var index in cxns){
                var cxn = cxns[index];
                var source = cxn.SourceObjDef ( );
                if(source.TypeNum() == Constants.OT_PERS){
                    var cxnss = source.CxnListFilter ( Constants.EDGES_INOUT, 210 );//person
                    for(var indexs in cxnss){
                        var xcxn = cxnss[indexs];
                        var xsource = xcxn.TargetObjDef ( );
                        return xsource;
                    }
                }
            }
        }catch(ex){
            Dialogs.MsgBox("ModelsData.getFukcniMisto : "+ex);
            throw ex;
        }
    }   
        
    this.getFunction = function(model){
        try{
            var occs = model.ObjOccList();
            for(var index in occs){
                var occ = occs[index];
                var def = occ.ObjDef();
                if(def.TypeNum() == Constants.OT_FUNC){
                    
                    var occs = def.OccListInModel (model);
                    //Dialogs.MsgBox("def : "+def.Name(lang)+" : "+occs.length);
                    if(occs.length > 0)
                        return def;
                }
            }
        }catch(ex){
            Dialogs.MsgBox("ModelsData.getFunction : "+ex);
            throw ex;
        }
        return null;
    }
}